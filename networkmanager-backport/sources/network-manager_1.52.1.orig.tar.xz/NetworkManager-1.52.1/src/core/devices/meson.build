# SPDX-License-Identifier: LGPL-2.1-or-later

subdir('adsl')

if enable_modem_manager
  subdir('wwan')
  subdir('bluetooth')
endif

if enable_wifi
  subdir('wifi')
endif

if enable_teamdctl
  subdir('team')
endif

if enable_ovs
  subdir('ovs')
endif

if enable_tests
  subdir('tests')
endif
